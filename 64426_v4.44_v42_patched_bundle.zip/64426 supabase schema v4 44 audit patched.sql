-- ============================================================
-- 64426 · Supabase 全新项目初始化脚本 v4.44（整体审计修复稿，未经过 PostgreSQL 执行验证）
-- 适用：全新空 Supabase 项目；未运行过 v1/v2/v3.1。
-- 本文件只供测试审查，未经过 PostgreSQL/Supabase 执行验证；不要直接运行或用于生产环境。
-- v4.23 新增：Before User Created Hook 的 IP/CIDR 拒绝名单。
-- v4.24 修正：管理员被停用/封禁时清除权限范围，避免恢复账号后权限静默复活。
-- v4.25 修正：注册 Hook 缺少 IP 元数据时不再放行，改为失败关闭，避免检查条件缺失时绕过拒绝名单。
-- v4.26 修正：收紧 public schema 中后续新建函数的默认 EXECUTE 权限，避免新增函数意外默认向客户端开放。
-- v4.27 修正：Storage 桶发生 ID 冲突时强制校正为私有桶及预期上传限制，避免旧桶 public=true 配置残留。
-- v4.28 修正：在 upsert 前检测预期 ID/名称不一致或名称冲突，明确中止而非误改已有对象引用。
-- v4.29 修正：撤销 PUBLIC/anon/authenticated 在 public schema 中的 CREATE 权限，避免客户端创建对象。
-- v4.30 修正：Auth Hook 改为 SECURITY INVOKER，并显式授予 supabase_auth_admin 对 public schema 的 USAGE；减少高权限函数风险并确保 Hook 能解析函数/表。
-- v4.31 修正：举报管理策略从 FOR ALL 收紧为仅 SELECT，避免有 INSERT 权限的举报管理员伪造他人举报；状态变更继续走带审计的 RPC。
-- v4.32 修正：默认函数 EXECUTE 权限撤销明确指定 FOR ROLE postgres。
-- v4.33 修正：统一审查现有函数 ACL。
-- v4.34 修正：仅收紧本脚本声明的 28 个应用函数，不批量修改 public 模式中的无关/扩展函数。
-- v4.35 修正：清理函数 EXECUTE 白名单中的重复授权语句；不改变实际权限范围。
-- v4.36 修正：对所有带权限范围的管理员内容/举报/粉丝审核变更 RPC 统一要求 JWT aal2。
-- v4.38 修正：访客及未审核账号不得读取内部内容；通过图片审核的有效 fan/admin 可查看获准内容；七天发言门槛保持独立。
-- v4.39 修正：被停权管理员的 scope 被清除后，恢复账号状态不会因残留 role=admin 自动恢复会员读取/发言能力；须由站主重新授予有效 scope。
-- v4.40 修正：管理员 scope 授予与降级/停权共享 profile 行锁，避免并发状态竞态；管理布尔参数拒绝 NULL，避免意外降级/解封。
-- v4.41 修复：①admin_scopes 先于引用它的 SQL 函数创建（否则第 92 行报错）；②站主/管理员的表策略与存储策略也要求 aal2；
--            ③新增链接/联系方式/引流词过滤 + 评论/返图/举报/点赞/审核/私信限流 + 恶意举报惩罚 + 举报内容快照；
--            ④昵称归一化保护（含零宽字符/全角/包含式保留词），站主自己可用 64426；⑤审核截图/返图数量上限；
--            ⑥返图上传不再写死 role=fan；⑦文本参数显式拒绝 NULL；⑧注册总量上限与开关。
-- v4.42 修复：前后端对账发现管理员删帖后无法清理 Storage 图片 → 版主可删“未被任何帖子引用”的返图对象，
--            并新增 admin_list_orphan_images() 列出需要清理的孤儿文件（数据库记录已删、文件删除失败时可重试）。
-- v4.44 修复：举报处罚去重、限流并发锁、审核截图可清理、成员列表分页。
-- v4.43 新增：my_scopes()（管理员读取自己被授予的权限范围，用于前端按权限显示页面）、
--            owner_list_members()（站主 aal2 下读取成员列表，用于“权限管理”页）。两者都只读，不改变任何权限。
-- 关键原则：站主身份独立存储；可有多个管理员；管理员不可变更站主；
-- 原始人物设定仅站主可见；原始文件桶仅站主访问；敏感管理 RPC 要求 MFA aal2。
-- Lv.1 注册未满 7 天禁止发帖/评论；Lv.2 注册满 7 天，仍须满足账号状态与角色要求。
-- 网页端只使用 anon/publishable key，绝不公开 service_role/secret key。
-- ============================================================
-- v4.26 默认函数执行权限收紧
-- 本脚本限定为全新空项目，并应由项目数据库管理员统一执行。
-- 全局默认不向 PUBLIC/anon/authenticated 开放此后新建函数的 EXECUTE；
-- 后续仅对确实需要通过 Data API 调用的函数显式 GRANT。
-- 注意：该设置仅影响 postgres 角色今后创建的函数，不会追溯修改已有函数，也不会自动改变其他创建角色的默认权限。
-- Revoke the PostgreSQL default PUBLIC EXECUTE for functions created by postgres.
alter default privileges for role postgres
  revoke execute on functions from public;
-- For future public-schema functions, explicitly remove default API-role grants.
alter default privileges for role postgres in schema public
  revoke execute on functions from anon, authenticated, service_role;

-- Prevent client roles from creating objects in the exposed public schema.
-- Keep schema USAGE intact; only CREATE is removed from public/client roles.
revoke create on schema public from public, anon, authenticated;

-- ============================================================

-- ============================================================
-- 64426 · Supabase 初始化脚本 v3.1（整理修订稿）
-- 用法：仅限从未运行过初始化脚本的空项目；先审查，再整份粘贴。
-- 注意：此文件未在你的项目上实测，运行前应先确认项目为空且无同名策略。
-- 原则：
--   1. 每张表都开启 RLS（行级安全），权限写在数据库里，不靠前端判断
--   2. 网页里只放 anon 公钥；service_role 密钥绝不放进网页或仓库
--   3. 原始设定只增不改；美化结果作为新版本保存
-- ============================================================


-- ---------- 1. 用户资料、站主与管理员权限 ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '匿名访客' check (char_length(display_name) between 1 and 30),
  role text not null default 'visitor' check (role in ('visitor','fan','admin')),
  role_before_admin text check (role_before_admin in ('visitor','fan')),
  account_status text not null default 'active' check (account_status in ('active','suspended','banned')),
  created_at timestamptz not null default now(),
  name_changed_at timestamptz,
  false_reports int not null default 0   -- v4.41: 被驳回的举报次数，客户端无权读写
);
alter table public.profiles enable row level security;

-- v4.41 [修复3/4] 文本归一化、内容过滤、昵称保护 ------------------------------------
-- 归一化：全角转半角、转小写、去掉空格/下划线/短横线/点/零宽字符
create function public.normalize_text(t text) returns text
language sql immutable set search_path = '' as $$
  select lower(regexp_replace(normalize(coalesce(t, ''), NFKC),
         '[\s_\-·•.\u200b-\u200f\u2060\ufeff]', '', 'g'))
$$;

-- 内容检查：网址、联系方式/引流、诈骗词、长数字串、刷屏。返回 null 表示通过。
create function public.spam_reason(t text) returns text
language plpgsql immutable set search_path = '' as $$
declare a text; b text;
begin
  if t is null or t = '' then return null; end if;
  a := lower(normalize(t, NFKC));
  b := regexp_replace(a, '[\s_\-·•.,，。、:：;；|/\\\u200b-\u200f\u2060\ufeff]', '', 'g');
  if a ~ '(https?:|www\.|[a-z0-9]\.(com|cn|net|org|top|xyz|cc|me|io|co|site|vip|club|link|app|shop|live|info|icu|work|fun|ink)(\M|/))'
    then return '网址链接'; end if;
  if a ~ '\m(tg|vx|wx)\M' or b ~ '(微信|薇信|威信|加v|v信|wechat|weixin|qq|加q|q群|电报|飞机号|telegram|whatsapp|私聊|私信我|加我|扫码|二维码|公众号|小程序|看主页|主页看|点我头像)'
    then return '联系方式或引流信息'; end if;
  if b ~ '(兼职|刷单|返利|博彩|赌博|赌场|彩票|贷款|套现|代充|代刷|涨粉|买粉|刷粉|引流|空降|裸聊|约炮|招代理|日结|佣金|投资理财|稳赚|带单|usdt|比特币|虚拟币|色情|成人视频)'
    then return '诈骗或广告内容'; end if;
  if b ~ '\d{9,}' then return '长数字串（疑似联系方式）'; end if;
  if a ~ '(.)\1{9,}' then return '重复刷屏'; end if;
  return null;
end $$;

create table public.reserved_terms (term text primary key);
alter table public.reserved_terms enable row level security;   -- 不建策略：客户端不可见
insert into public.reserved_terms (term) values
  ('64426'),('站主'),('管理员'),('官方'),('客服'),('运营'),('版主'),('系统'),
  ('admin'),('administrator'),('official'),('support'),('moderator'),
  ('owner'),('staff'),('system'),('root'),('supabase');

-- 昵称唯一性按归一化结果判断，防止零宽字符/空格/全角变体重名
create unique index profiles_display_name_normalized_unique
  on public.profiles (public.normalize_text(display_name));

-- 昵称守卫：字符集、保留词（站主本人除外，所以只有站主能用 64426）、引流内容
-- INSERT 由系统生成默认昵称，不检查（避免随机串偶然命中保留词）。
create function public.profiles_name_guard() returns trigger
language plpgsql security definer set search_path = '' as $$
declare n text;
begin
  if tg_op = 'INSERT' then return new; end if;
  n := btrim(new.display_name);
  new.display_name := n;
  if n !~ '^[A-Za-z0-9_\- ·\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]+$' then
    raise exception 'NAME_FORMAT: 昵称只能用中英文、数字、下划线、短横线和空格';
  end if;
  if not exists (select 1 from public.site_owner so where so.user_id = new.id) then
    if exists (select 1 from public.reserved_terms r
               where position(public.normalize_text(r.term) in public.normalize_text(n)) > 0) then
      raise exception 'NAME_RESERVED: 昵称包含受保护的词';
    end if;
    if public.spam_reason(n) is not null then
      raise exception 'CONTENT_BLOCKED: 昵称疑似包含链接或联系方式';
    end if;
  end if;
  return new;
end $$;
create trigger profiles_name_guard
  before insert or update of display_name on public.profiles
  for each row execute function public.profiles_name_guard();

-- 站主身份单独保存，不使用可由管理员变更的 profiles.role 判断。
create table public.site_owner (
  singleton boolean primary key default true check (singleton),
  user_id uuid not null unique references auth.users(id) on delete restrict,
  set_at timestamptz not null default now()
);
alter table public.site_owner enable row level security;

create table public.security_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_user_id uuid references auth.users(id) on delete set null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.security_audit_log enable row level security;

create function public.is_owner() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.site_owner so where so.user_id = (select auth.uid()));
$$;
-- v4.41 [修复2] 站主身份 + 当前会话已通过两步验证(aal2)。数据访问策略一律用它，密码泄露也读不到数据。
create function public.is_owner_aal2() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_owner() and coalesce((select auth.jwt() ->> 'aal'), '') = 'aal2';
$$;

-- v4.41 [修复1] admin_scopes 必须先于引用它的 SQL 函数（is_admin）创建，否则建函数时报 relation does not exist。
create table public.admin_scopes (
  user_id uuid not null references auth.users(id) on delete cascade,
  scope text not null check (scope in ('content_management','content_moderation','fan_review','report_management')),
  granted_by uuid references auth.users(id) on delete set null,
  granted_at timestamptz not null default now(),
  primary key (user_id, scope)
);
alter table public.admin_scopes enable row level security;
create policy "owner_read_admin_scopes" on public.admin_scopes
  for select to authenticated using (public.is_owner_aal2());

create function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  -- v4.41: 有效管理员 = 站主(aal2)，或 aal2 会话下 role=admin、状态正常且至少持有一个 scope。
  select public.is_owner_aal2() or (
    coalesce((select auth.jwt() ->> 'aal'), '') = 'aal2'
    and exists (
      select 1
      from public.profiles p
      join public.admin_scopes s on s.user_id = p.id
      where p.id = (select auth.uid())
        and p.role = 'admin'
        and p.account_status = 'active'
    )
  );
$$;

create function public.has_admin_scope(p_scope text) returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_owner_aal2() or (
    coalesce((select auth.jwt() ->> 'aal'), '') = 'aal2'
    and exists (
      select 1 from public.admin_scopes s
      join public.profiles p on p.id = s.user_id
      where s.user_id = (select auth.uid())
        and s.scope = p_scope
        and p.role = 'admin'
        and p.account_status = 'active'
    )
  );
$$;

create function public.owner_set_admin_scope(p_user_id uuid, p_scope text, p_grant boolean) returns void
language plpgsql security definer set search_path = '' as $$
declare
  target_role text;
  target_status text;
begin
  if not public.is_owner() then raise exception 'owner only'; end if;
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if p_scope is null or p_scope not in ('content_management','content_moderation','fan_review','report_management') then raise exception 'invalid scope'; end if;
  if p_grant is null then raise exception 'grant flag is required'; end if;
  if exists (select 1 from public.site_owner where user_id = p_user_id) then raise exception 'owner is immutable'; end if;
  -- Lock the profile row before checking role/status. This serializes scope grants
  -- against concurrent demotion and suspension/ban operations on the same account.
  select role, account_status into target_role, target_status
  from public.profiles where id = p_user_id for update;
  if not found then raise exception 'account not found'; end if;
  if target_role <> 'admin' then raise exception 'target must be an admin'; end if;
  if p_grant and target_status <> 'active' then raise exception 'target admin account must be active'; end if;
  if p_grant then
    insert into public.admin_scopes(user_id, scope, granted_by)
    values (p_user_id, p_scope, auth.uid()) on conflict (user_id, scope) do nothing;
  else
    delete from public.admin_scopes where user_id = p_user_id and scope = p_scope;
  end if;
  insert into public.security_audit_log(actor_id, action, target_user_id, details)
  values (auth.uid(), case when p_grant then 'grant_admin_scope' else 'revoke_admin_scope' end,
          p_user_id, jsonb_build_object('scope', p_scope));
end $$;

create function public.is_fan() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_admin() or exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'fan' and p.account_status = 'active');
$$;
create function public.my_role() returns text
language sql stable security definer set search_path = '' as $$
  select case when public.is_owner() then 'owner' else p.role end
  from public.profiles p where p.id = (select auth.uid());
$$;
create function public.can_view(v text) returns boolean
language sql stable security definer set search_path = '' as $$
  -- 'public' 指已通过审核的有效会员，不含未登录访客；private 只有 aal2 的站主可见。
  select coalesce(
    public.is_owner_aal2()
    or (public.is_fan() and v in ('public', 'fans')),
    false
  );
$$;

create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  -- v4.41: 注册开关与人数上限
  if coalesce(public.setting('signup_open'), 'true') <> 'true' then
    raise exception 'SIGNUP_CLOSED: 暂停注册';
  end if;
  if (select count(*) from public.profiles) >= coalesce(nullif(public.setting('max_users'), '')::int, 300) then
    raise exception 'SIGNUP_CLOSED: 注册名额已满';
  end if;
  -- 注册时不信任客户端元数据作为昵称；先生成基于 Auth UID 的唯一默认名，
  -- 用户注册成功后再通过受冷却限制的资料更新流程修改昵称。
  insert into public.profiles (id, display_name)
  values (new.id, '访客-' || left(replace(new.id::text, '-', ''), 25));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- 本人资料安全读取：不向其他用户暴露邮箱。
create function public.my_account() returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  select jsonb_build_object(
    'uid', p.id,
    'display_name', p.display_name,
    'role', case when public.is_owner() then 'owner' else p.role end,
    'account_status', p.account_status,
    'created_at', p.created_at,
    'name_changed_at', p.name_changed_at,
    'account_level', case when p.created_at <= now() - interval '7 days' then 2 else 1 end,
    'days_until_level_2', greatest(0, ceil(extract(epoch from ((p.created_at + interval '7 days') - now())) / 86400)::int),
    'email', u.email
  ) into result
  from public.profiles p join auth.users u on u.id = p.id
  where p.id = (select auth.uid());
  return result;
end $$;

-- 账号等级由数据库时间计算，不接受客户端自行提交等级。
-- Lv.1：注册未满 7 天；Lv.2：注册满 7 天。等级不自动授予 fan/admin 角色。
create function public.my_account_level() returns integer
language sql stable security definer set search_path = '' as $$
  select case
    when p.created_at <= now() - interval '7 days' then 2
    else 1
  end
  from public.profiles p
  where p.id = (select auth.uid());
$$;

-- 发言资格：账号必须活跃、注册满 7 天，并已获得 fan/admin 身份。
-- 管理员身份不会绕过七天限制；站主也遵守账号年龄规则。
create function public.can_speak() returns boolean
language sql stable security definer set search_path = '' as $$
  -- Account age remains independent from approval and effective role.
  -- An admin whose scopes were cleared must not retain speaking rights just
  -- because profiles.role still says 'admin'; owner must regrant a scope first.
  select coalesce(exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid())
      and p.account_status = 'active'
      and (
        public.is_owner_aal2()
        or p.role = 'fan'
        or (p.role = 'admin' and exists (
          select 1 from public.admin_scopes s where s.user_id = p.id
        ))
      )
      and p.created_at <= now() - interval '7 days'
  ), false);
$$;

-- 仅站主可授予/撤销管理员；要求本次会话 JWT 的 aal2。
create function public.owner_set_admin(p_user_id uuid, p_make_admin boolean) returns void
language plpgsql security definer set search_path = '' as $$
declare old_role text; new_role text;
begin
  if not public.is_owner() then raise exception 'owner only'; end if;
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if p_make_admin is null then raise exception 'admin flag is required'; end if;
  if p_user_id = (select auth.uid()) then raise exception 'cannot change owner role'; end if;
  select role into old_role from public.profiles where id = p_user_id for update;
  if not found then raise exception 'account not found'; end if;
  if exists (select 1 from public.site_owner where user_id = p_user_id) then raise exception 'owner is immutable'; end if;
  if p_make_admin then
    if exists (
      select 1 from public.profiles
      where id = p_user_id and account_status <> 'active'
    ) then
      raise exception 'target account must be active before admin promotion';
    end if;
    -- Admin promotion must not bypass the image-review gate: only an already approved fan may be promoted.
    if old_role not in ('fan', 'admin') then
      raise exception 'target must pass image review before admin promotion';
    end if;
    if old_role <> 'admin' then
      update public.profiles set role_before_admin = old_role, role = 'admin' where id = p_user_id;
      new_role := 'admin';
    else
      new_role := old_role;
    end if;
  else
    if old_role = 'admin' then
      update public.profiles set role = coalesce(role_before_admin, 'visitor'), role_before_admin = null where id = p_user_id;
      delete from public.admin_scopes where user_id = p_user_id;
      select role into new_role from public.profiles where id = p_user_id;
    else
      new_role := old_role;
    end if;
  end if;
  insert into public.security_audit_log(actor_id, action, target_user_id, details)
  values (auth.uid(), case when p_make_admin then 'grant_admin' else 'revoke_admin' end, p_user_id,
          jsonb_build_object('previous_role', old_role, 'new_role', new_role));
end $$;

create function public.owner_set_account_status(p_user_id uuid, p_status text) returns void
language plpgsql security definer set search_path = '' as $$
declare
  old_status text;
  old_role text;
  cleared_scope_count integer := 0;
begin
  if not public.is_owner() then raise exception 'owner only'; end if;
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if p_status is null or p_status not in ('active','suspended','banned') then raise exception 'invalid status'; end if;
  if exists (select 1 from public.site_owner where user_id = p_user_id) then raise exception 'cannot change owner status'; end if;
  select account_status, role into old_status, old_role
  from public.profiles where id = p_user_id for update;
  if not found then raise exception 'account not found'; end if;
  update public.profiles set account_status = p_status where id = p_user_id;

  -- Fail closed: when an admin is suspended/banned, remove all scopes instead of
  -- leaving dormant privileges that silently reactivate if the account is restored.
  if p_status <> 'active' and old_role = 'admin' then
    delete from public.admin_scopes where user_id = p_user_id;
    get diagnostics cleared_scope_count = row_count;
  end if;

  insert into public.security_audit_log(actor_id, action, target_user_id, details)
  values (auth.uid(), 'account_status_change', p_user_id,
          jsonb_build_object('old', old_status, 'new', p_status,
                             'admin_scopes_cleared', cleared_scope_count));
end $$;

create policy "profiles_select" on public.profiles for select to authenticated
  using (id = (select auth.uid()) or public.is_fan());
create policy "profiles_update_own" on public.profiles for update to authenticated
using (id = (select auth.uid()) and account_status = 'active')
with check (id = (select auth.uid()) and account_status = 'active');

-- 昵称冷却由数据库强制执行：30 天内不能再次更改；客户端不能自行写入 name_changed_at。
create function public.enforce_nickname_change_cooldown() returns trigger
language plpgsql set search_path = '' as $$
begin
  if new.display_name is distinct from old.display_name then
    if old.name_changed_at is not null
       and old.name_changed_at > now() - interval '30 days' then
      raise exception 'nickname can only be changed once every 30 days';
    end if;
    new.name_changed_at := now();
  else
    new.name_changed_at := old.name_changed_at;
  end if;
  return new;
end $$;
create trigger profiles_nickname_cooldown
  before update of display_name, name_changed_at on public.profiles
  for each row execute function public.enforce_nickname_change_cooldown();
revoke execute on function public.enforce_nickname_change_cooldown() from public, anon, authenticated;
-- 资料只能由本人读/改允许字段；站主与管理员角色不通过直接表写入管理。
revoke all on public.profiles from anon, authenticated;
-- Removed: do not grant account_status/name_changed_at column access; final allowlist is at section 7.
grant update (display_name) on public.profiles to authenticated;

create policy "owner_read_site_owner" on public.site_owner for select to authenticated using (public.is_owner_aal2());
create policy "owner_read_audit" on public.security_audit_log for select to authenticated using (public.is_owner_aal2());
revoke all on public.site_owner, public.security_audit_log from anon, authenticated;
grant select on public.site_owner, public.security_audit_log to authenticated;
revoke execute on function public.is_owner() from public, anon;
revoke execute on function public.is_admin() from public, anon;
revoke execute on function public.is_fan() from public, anon;
revoke execute on function public.my_role() from public, anon;
revoke execute on function public.can_view(text) from public, anon;
revoke execute on function public.my_account() from public, anon;
revoke execute on function public.my_account_level() from public, anon;
revoke execute on function public.can_speak() from public, anon;
revoke execute on function public.owner_set_admin(uuid, boolean) from public, anon;
revoke execute on function public.owner_set_account_status(uuid, text) from public, anon;
revoke execute on function public.has_admin_scope(text) from public, anon;
revoke execute on function public.owner_set_admin_scope(uuid, text, boolean) from public, anon;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
-- ---------- 2. 美化模板 ----------
create table public.templates (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  description text not null default '' check (char_length(description) <= 300),
  config jsonb not null default '{}',
  visibility text not null default 'private' check (visibility in ('private','public')),
  created_at timestamptz not null default now()
);
alter table public.templates enable row level security;

create policy "templates_select" on public.templates
  for select to authenticated using (public.can_view(visibility));
create policy "templates_admin_all" on public.templates
  for all to authenticated using (public.has_admin_scope('content_management')) with check (public.has_admin_scope('content_management'));


-- ---------- 3. 人物设定（原文只增不改） ----------
create table public.characters (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  summary text not null default '' check (char_length(summary) <= 500),
  tags text[] not null default '{}',
  visibility text not null default 'private' check (visibility in ('private','fans','public')),
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.characters enable row level security;

create function public.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at := now(); return new; end $$;

create trigger characters_touch before update on public.characters
  for each row execute function public.touch_updated_at();

create policy "characters_select" on public.characters
  for select to authenticated using (public.can_view(visibility));
create policy "characters_admin_all" on public.characters
  for all to authenticated using (public.has_admin_scope('content_management')) with check (public.has_admin_scope('content_management'));

create table public.character_versions (
  id uuid primary key default gen_random_uuid(),
  character_id uuid not null references public.characters(id) on delete restrict,
  kind text not null check (kind in ('original','beautified')),
  template_id uuid references public.templates(id) on delete set null,
  content text not null,
  created_at timestamptz not null default now()
);
alter table public.character_versions enable row level security;

-- Character versions are internal content. No anon SELECT policy exists.
-- Approved active members may read eligible beautified versions; originals remain owner-only.
create policy "versions_select_authenticated" on public.character_versions
  for select to authenticated using (
    (kind = 'original' and public.is_owner_aal2())
    or
    (kind = 'beautified' and exists (
      select 1 from public.characters c
      where c.id = character_versions.character_id
        and public.can_view(c.visibility)
    ))
  );
create policy "versions_admin_insert" on public.character_versions
  for insert to authenticated
  with check (public.is_owner_aal2() or (public.has_admin_scope('content_management') and kind = 'beautified'));
-- 通过 API 只能改/删美化版本；原文版本改不了、删不了（要改就新增一个 original 版本）
create policy "versions_admin_update_beautified" on public.character_versions
  for update to authenticated
  using (kind = 'beautified' and (public.is_owner_aal2() or public.has_admin_scope('content_management')))
  with check (kind = 'beautified' and (public.is_owner_aal2() or public.has_admin_scope('content_management')));
create policy "versions_admin_delete_beautified" on public.character_versions
  for delete to authenticated using (kind = 'beautified' and (public.is_owner_aal2() or public.has_admin_scope('content_management')));


-- ---------- 4. 粉丝审核 ----------
create table public.proof_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  image_path text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  note text check (char_length(note) <= 300),
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.proof_submissions enable row level security;

-- 每人同一时间只能有一条待审核，避免刷屏占空间
create unique index proof_one_pending_per_user
  on public.proof_submissions (user_id) where status = 'pending';

create policy "proof_insert_own" on public.proof_submissions
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and split_part(image_path, '/', 1) = (select auth.uid())::text
    and status = 'pending'
    and reviewed_by is null
    and exists (
      select 1 from public.profiles p
      where p.id = (select auth.uid())
        and p.account_status = 'active'
    )
  );
-- 文件记录必须指向已存在的 Storage 对象；避免伪造不存在的图片路径。
create function public.validate_proof_storage_reference() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if not exists (
    select 1 from storage.objects o
    where o.bucket_id = 'proofs' and o.name = new.image_path
  ) then
    raise exception 'proof image object not found';
  end if;
  return new;
end $$;
create trigger proof_storage_reference_check
  before insert or update of image_path on public.proof_submissions
  for each row execute function public.validate_proof_storage_reference();
revoke execute on function public.validate_proof_storage_reference() from public, anon, authenticated;

create policy "proof_select_own_or_admin" on public.proof_submissions
  for select to authenticated using (user_id = (select auth.uid()) or public.has_admin_scope('fan_review'));
-- 客户端无 proof_submissions 的 UPDATE/DELETE 权限；审核统一走 admin_review_proof RPC。

-- 站主把状态改成 approved 时，自动把该用户升为 fan
create function public.review_proof() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.status is distinct from old.status then
    new.reviewed_at := now();
    new.reviewed_by := (select auth.uid());
    if new.status = 'approved' then
      update public.profiles set role = 'fan' where id = new.user_id and role = 'visitor' and account_status = 'active';
    end if;
  end if;
  return new;
end $$;

create trigger proof_review before update on public.proof_submissions
  for each row execute function public.review_proof();

-- 审核必须通过受控 RPC，客户端不直接获得 proof_submissions 的 UPDATE 权限。
create function public.admin_review_proof(p_id uuid, p_status text, p_note text default null) returns void
language plpgsql security definer set search_path = '' as $$
declare old_status text; target_user uuid;
begin
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if not public.has_admin_scope('fan_review') then raise exception 'not allowed'; end if;
  if p_status is null or p_status not in ('approved','rejected') then raise exception 'invalid review status'; end if;
  select status, user_id into old_status, target_user
  from public.proof_submissions where id = p_id for update;
  if not found then raise exception 'submission not found'; end if;
  if old_status <> 'pending' then raise exception 'submission already reviewed'; end if;
  update public.proof_submissions
     set status = p_status, note = coalesce(p_note, note)
   where id = p_id;
  insert into public.security_audit_log(actor_id, action, target_user_id, details)
  values (auth.uid(), 'proof_review', target_user,
          jsonb_build_object('submission_id', p_id, 'old_status', old_status, 'new_status', p_status));
end $$;


-- ---------- 5. 返图广场 ----------
create table public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  caption text not null default '' check (char_length(caption) <= 500),
  image_path text not null,
  status text not null default 'published' check (status in ('published','hidden')),
  created_at timestamptz not null default now()
);
alter table public.posts enable row level security;

create policy "posts_select" on public.posts
  for select to authenticated
  using (
    (public.is_fan() or public.has_admin_scope('content_moderation'))
    and (status = 'published' or user_id = (select auth.uid()) or public.has_admin_scope('content_moderation'))
  );
-- 帖子引用的返图必须已经上传到 gallery 桶；路径归属仍由 RLS 另外校验。
create function public.validate_gallery_storage_reference() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if not exists (
    select 1 from storage.objects o
    where o.bucket_id = 'gallery' and o.name = new.image_path
  ) then
    raise exception 'gallery image object not found';
  end if;
  return new;
end $$;
create trigger post_storage_reference_check
  before insert or update of image_path on public.posts
  for each row execute function public.validate_gallery_storage_reference();
revoke execute on function public.validate_gallery_storage_reference() from public, anon, authenticated;

create policy "posts_insert_fan" on public.posts
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and split_part(image_path, '/', 1) = (select auth.uid())::text
    and public.can_speak()
    and status = 'published'
  );
create policy "posts_delete_own" on public.posts
  for delete to authenticated using (user_id = (select auth.uid()));
revoke update on public.posts from authenticated;   -- 隐藏/恢复走下面的管理员函数

create table public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);
alter table public.post_likes enable row level security;

create policy "likes_select" on public.post_likes
  for select to authenticated using (
    (public.is_fan() or public.has_admin_scope('content_moderation'))
    and exists (
      select 1 from public.posts p
      where p.id = post_likes.post_id
        and (p.status = 'published' or p.user_id = (select auth.uid()) or public.has_admin_scope('content_moderation'))
    )
  );
create policy "likes_insert_fan" on public.post_likes
  for insert to authenticated with check (user_id = (select auth.uid()) and public.is_fan());
create policy "likes_delete_own" on public.post_likes
  for delete to authenticated using (user_id = (select auth.uid()));

create table public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  parent_id uuid,   -- 楼中楼；下方复合外键确保父评论属于同一帖子
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  status text not null default 'visible' check (status in ('visible','hidden')),
  created_at timestamptz not null default now(),
  unique (id, post_id),
  constraint comments_parent_same_post_fk
    foreign key (parent_id, post_id)
    references public.comments(id, post_id) on delete cascade
);
alter table public.comments enable row level security;

create policy "comments_select" on public.comments
  for select to authenticated
  using (
    (public.is_fan() or public.has_admin_scope('content_moderation'))
    and (status = 'visible' or user_id = (select auth.uid()) or public.has_admin_scope('content_moderation'))
  );
create policy "comments_insert_fan" on public.comments
  for insert to authenticated
  with check (user_id = (select auth.uid()) and public.can_speak() and status = 'visible');
create policy "comments_delete_own" on public.comments
  for delete to authenticated using (user_id = (select auth.uid()));
revoke update on public.comments from authenticated;

-- 帖子列表（带点赞数、评论数、作者昵称）；用调用者权限，所以仍受上面的规则约束
create view public.posts_with_counts with (security_invoker = true) as
select p.*,
       pr.display_name as author_name,
       (select count(*) from public.post_likes l where l.post_id = p.id) as like_count,
       (select count(*) from public.comments c
         where c.post_id = p.id and c.status = 'visible') as comment_count
from public.posts p
left join public.profiles pr on pr.id = p.user_id;

-- 举报
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  target_type text not null check (target_type in ('post','comment')),
  target_id uuid not null,
  reason text not null default '' check (char_length(reason) <= 300),
  target_snapshot text,   -- v4.41: 举报时的内容快照，防止作者删帖销毁证据
  status text not null default 'open' check (status in ('open','resolved','dismissed')),
  penalty_counted boolean not null default false, -- 同一举报最多计入一次恶意举报处罚
  created_at timestamptz not null default now(),
  unique (reporter_id, target_type, target_id)
);
alter table public.reports enable row level security;

-- 举报目标必须真实存在，且不能举报自己的帖子/评论。
-- 使用受控触发器验证，避免客户端提交任意 UUID 形成无效举报记录。
create function public.validate_report_target() returns trigger
language plpgsql security definer set search_path = '' as $$
declare target_owner uuid; target_status text; snap text;
begin
  if new.target_type = 'post' then
    select user_id, status, left('[图片] ' || image_path || ' ' || caption, 500)
      into target_owner, target_status, snap
      from public.posts where id = new.target_id;
  elsif new.target_type = 'comment' then
    select user_id, status, left(body, 500)
      into target_owner, target_status, snap
      from public.comments where id = new.target_id;
  else
    raise exception 'invalid report target type';
  end if;
  if not found then raise exception 'report target not found'; end if;
  if target_owner = new.reporter_id then raise exception 'cannot report own content'; end if;
  if target_status in ('hidden') then
    -- Hidden posts/comments can still be reported by moderators' discovery flows;
    -- target existence and ownership are the security invariants here.
    null;
  end if;
  new.target_snapshot := snap;
  return new;
end $$;
create trigger reports_validate_target
  before insert or update of target_type, target_id, reporter_id on public.reports
  for each row execute function public.validate_report_target();
revoke execute on function public.validate_report_target() from public, anon, authenticated;

create policy "reports_insert" on public.reports
  for insert to authenticated with check (
    reporter_id = (select auth.uid())
    and status = 'open'
    and public.is_fan()
    and exists (
      select 1 from public.profiles p
      where p.id = (select auth.uid())
        and p.account_status = 'active'
    )
  );
-- Report managers may read reports, but must use audited RPCs to change their status.
-- Do not use FOR ALL here: the table grants INSERT to authenticated users, so a broad
-- admin policy would also let report managers forge reports attributed to other users.
create policy "reports_admin_select" on public.reports
  for select to authenticated using (public.has_admin_scope('report_management'));


-- 举报处理通过专用 RPC，避免客户端直接改状态而不留审计记录。
create function public.admin_set_report_status(p_id uuid, p_status text) returns void
language plpgsql security definer set search_path = '' as $$
declare old_status text; rep uuid; already_counted boolean;
begin
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if not public.has_admin_scope('report_management') then raise exception 'not allowed'; end if;
  if p_status is null or p_status not in ('open','resolved','dismissed') then raise exception 'bad status'; end if;
  select status, reporter_id, penalty_counted into old_status, rep, already_counted
    from public.reports where id = p_id for update;
  if not found then raise exception 'report not found'; end if;
  update public.reports set status = p_status where id = p_id;
  -- 同一条举报无论如何切换状态，恶意举报处罚最多累计一次。
  if p_status = 'dismissed' and not already_counted then
    update public.profiles
       set false_reports = false_reports + 1,
           account_status = case when false_reports + 1 >= 5 and account_status = 'active' and role <> 'admin'
                                 then 'suspended' else account_status end
     where id = rep
       and not exists (select 1 from public.site_owner so where so.user_id = rep);
    update public.reports set penalty_counted = true where id = p_id;
  end if;
  insert into public.security_audit_log(actor_id, action, details)
  values (auth.uid(), 'report_status_change', jsonb_build_object('report_id', p_id, 'old_status', old_status, 'new_status', p_status));
end $$;

-- ---------- 6. 管理员操作函数（隐藏 / 恢复） ----------
create function public.admin_set_post_status(p_id uuid, p_status text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if not public.has_admin_scope('content_moderation') then raise exception 'not allowed'; end if;
  if p_status is null or p_status not in ('published','hidden') then raise exception 'bad status'; end if;
  update public.posts set status = p_status where id = p_id;
  if not found then raise exception 'post not found'; end if;
  insert into public.security_audit_log(actor_id, action, details)
  values (auth.uid(), 'post_status_change', jsonb_build_object('post_id', p_id, 'new_status', p_status));
end $$;

create function public.admin_delete_post(p_id uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare found_post uuid;
begin
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if not public.has_admin_scope('content_moderation') then raise exception 'not allowed'; end if;
  select user_id into found_post from public.posts where id = p_id for update;
  if not found then raise exception 'post not found'; end if;
  insert into public.security_audit_log(actor_id, action, target_user_id, details)
  values (auth.uid(), 'admin_delete_post', found_post, jsonb_build_object('post_id', p_id));
  delete from public.posts where id = p_id;
end $$;

create function public.admin_delete_comment(p_id uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare found_comment record;
begin
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if not public.has_admin_scope('content_moderation') then raise exception 'not allowed'; end if;
  select user_id, post_id into found_comment from public.comments where id = p_id for update;
  if not found then raise exception 'comment not found'; end if;
  insert into public.security_audit_log(actor_id, action, target_user_id, details)
  values (auth.uid(), 'admin_delete_comment', found_comment.user_id,
          jsonb_build_object('comment_id', p_id, 'post_id', found_comment.post_id));
  delete from public.comments where id = p_id;
end $$;

create function public.admin_set_comment_status(p_id uuid, p_status text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if not public.has_admin_scope('content_moderation') then raise exception 'not allowed'; end if;
  if p_status is null or p_status not in ('visible','hidden') then raise exception 'bad status'; end if;
  update public.comments set status = p_status where id = p_id;
  if not found then raise exception 'comment not found'; end if;
  insert into public.security_audit_log(actor_id, action, details)
  values (auth.uid(), 'comment_status_change', jsonb_build_object('comment_id', p_id, 'new_status', p_status));
end $$;

revoke execute on function public.review_proof() from public, anon, authenticated;
revoke execute on function public.touch_updated_at() from public, anon, authenticated;
-- Trigger functions are invoked by PostgreSQL triggers; do not grant direct client execution.

revoke execute on function public.admin_set_post_status(uuid, text) from public, anon;
revoke execute on function public.admin_set_comment_status(uuid, text) from public, anon;
revoke execute on function public.admin_delete_post(uuid) from public, anon;
revoke execute on function public.admin_delete_comment(uuid) from public, anon;
revoke execute on function public.admin_review_proof(uuid, text, text) from public, anon;
revoke execute on function public.admin_set_report_status(uuid, text) from public, anon;
-- ---------- 6.5 站主专属私信：用户只能联系站主，站主可主动联系任意用户 ----------
-- 规则：未收到站主回复前，每个用户只能发送一条首条私信；站主回复过后，该用户可继续发送，仍受频率限制。
-- 拉黑优先于历史回复解锁；站主可继续主动联系被拉黑用户，但被拉黑用户不能向站主发送。
create table public.private_messages (
  id uuid primary key default gen_random_uuid(),
  message_seq bigint generated always as identity unique,
  sender_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(btrim(body)) between 1 and 3000),
  created_at timestamptz not null default now(),
  constraint private_messages_no_self_message check (sender_id <> recipient_id)
);
alter table public.private_messages enable row level security;

create policy "private_messages_read_participants" on public.private_messages
  for select to authenticated
  using (
    (public.is_owner_aal2() or public.is_fan())
    and (sender_id = (select auth.uid()) or recipient_id = (select auth.uid()))
  );
-- 不创建客户端 INSERT/UPDATE/DELETE 策略；所有发送必须走受控 RPC。

create table public.private_message_blocks (
  user_id uuid primary key references auth.users(id) on delete cascade,
  blocked_by uuid not null references auth.users(id) on delete restrict,
  reason text not null default '' check (char_length(reason) <= 300),
  created_at timestamptz not null default now()
);
alter table public.private_message_blocks enable row level security;
create policy "private_message_blocks_owner_read" on public.private_message_blocks
  for select to authenticated using (public.is_owner_aal2());
-- 不开放客户端直接写入拉黑表；站主只能通过 owner_set_private_message_block RPC 操作。

create function public.send_private_message(p_recipient_id uuid, p_body text) returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  actor uuid := auth.uid();
  owner_id uuid;
  msg_id uuid;
  sent_recently integer;
begin
  if actor is null then raise exception 'authentication required'; end if;
  if p_body is null or char_length(btrim(p_body)) < 1 or char_length(p_body) > 3000 then
    raise exception 'message must contain 1-3000 characters';
  end if;
  select so.user_id into owner_id from public.site_owner so where so.singleton = true;
  if owner_id is null then raise exception 'site owner is not initialized'; end if;
  if actor = owner_id then
    if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
    if p_recipient_id = owner_id then raise exception 'cannot message yourself'; end if;
    if not exists (select 1 from public.profiles p where p.id = p_recipient_id) then
      raise exception 'recipient not found';
    end if;
    -- 站主可主动联系任何已注册用户；该方向不受对方拉黑记录限制。
  else
    if p_recipient_id <> owner_id then raise exception 'users may only message the site owner'; end if;
    if not public.is_fan() then raise exception 'image review approval required'; end if;
    -- 同一发送者的事务串行化，避免并发请求同时通过“首条消息”检查。
    perform pg_advisory_xact_lock(hashtext(actor::text));
    if not exists (
      select 1 from public.profiles p
      where p.id = actor and p.account_status = 'active'
    ) then raise exception 'active account required'; end if;
    if exists (select 1 from public.private_message_blocks b where b.user_id = actor) then
      raise exception 'messaging is blocked by the site owner';
    end if;
    -- 只以用户最早发给站主的消息作为首次联系基准。
    -- 站主在该消息之后回复一次，即永久解锁后续沟通；站主更早的主动消息不算回复。
    -- message_seq 是数据库生成的递增序号，避免 created_at 时间精度相同导致解锁判断不稳定。
    if exists (
      select 1
      from (
        select m.message_seq
        from public.private_messages m
        where m.sender_id = actor and m.recipient_id = owner_id
        order by m.message_seq asc
        limit 1
      ) as first_inbound
      where not exists (
        select 1 from public.private_messages owner_reply
        where owner_reply.sender_id = owner_id
          and owner_reply.recipient_id = actor
          and owner_reply.message_seq > first_inbound.message_seq
      )
    ) then
      raise exception 'please wait for the site owner to reply';
    end if;
    -- 已解锁用户限每分钟最多 5 条，防止刷屏。
    select count(*) into sent_recently
      from public.private_messages m
      where m.sender_id = actor and m.recipient_id = owner_id
        and m.created_at > now() - interval '1 minute';
    if sent_recently >= 5 then raise exception 'message rate limit exceeded'; end if;
  end if;
  insert into public.private_messages(sender_id, recipient_id, body)
  values (actor, p_recipient_id, btrim(p_body))
  returning id into msg_id;
  return msg_id;
end $$;

create function public.owner_set_private_message_block(p_user_id uuid, p_block boolean, p_reason text default '') returns void
language plpgsql security definer set search_path = '' as $$
declare
  owner_id uuid;
  clean_reason text := coalesce(p_reason, '');
begin
  if not public.is_owner() then raise exception 'owner only'; end if;
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if p_block is null then raise exception 'block flag is required'; end if;
  select so.user_id into owner_id from public.site_owner so where so.singleton = true;
  if p_user_id = owner_id then raise exception 'cannot block the site owner'; end if;
  if char_length(clean_reason) > 300 then raise exception 'reason too long'; end if;
  if not exists (select 1 from public.profiles p where p.id = p_user_id) then
    raise exception 'target account not found';
  end if;
  -- Use the same per-user transaction lock as send_private_message so a block
  -- cannot race with an in-flight send after the sender has checked the block table.
  perform pg_advisory_xact_lock(hashtext(p_user_id::text));
  if p_block then
    insert into public.private_message_blocks(user_id, blocked_by, reason)
    values (p_user_id, owner_id, clean_reason)
    on conflict (user_id) do update set blocked_by = excluded.blocked_by,
      reason = excluded.reason, created_at = now();
  else
    delete from public.private_message_blocks where user_id = p_user_id;
  end if;
  insert into public.security_audit_log(actor_id, action, target_user_id, details)
  values (owner_id, case when p_block then 'private_message_block' else 'private_message_unblock' end,
          p_user_id, jsonb_build_object('reason', clean_reason));
end $$;

revoke execute on function public.send_private_message(uuid, text) from public, anon;
revoke execute on function public.owner_set_private_message_block(uuid, boolean, text) from public, anon;
-- ---------- 6.8 v4.41：内容过滤、限流、注册上限 ----------
create function public.guard_text() returns trigger
language plpgsql set search_path = '' as $$
declare val text := to_jsonb(new) ->> tg_argv[0]; why text;
begin
  if val is not null and not public.is_owner_aal2() then
    why := public.spam_reason(val);
    if why is not null then
      raise exception 'CONTENT_BLOCKED: 内容疑似包含%，已被拦截', why;
    end if;
  end if;
  return new;
end $$;

-- 限流需要读全表计数，必须 SECURITY DEFINER 以绕过 RLS（举报人本来读不到自己的举报）
create function public.guard_rate() returns trigger
language plpgsql security definer set search_path = '' as $$
declare u uuid := (to_jsonb(new) ->> tg_argv[0])::uuid; n int;
begin
  if public.is_owner_aal2() then return new; end if;
  -- 同一用户、同一业务表的计数与插入串行化，避免并发请求同时穿透限流。
  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(tg_table_name || ':' || coalesce(u::text, 'null'), 0)
  );
  execute format('select count(*) from public.%I where %I = $1 and created_at > now() - $2::interval',
                 tg_table_name, tg_argv[0])
    into n using u, tg_argv[1];
  if n >= tg_argv[2]::int then
    raise exception 'RATE_LIMIT: 操作过于频繁，请稍后再试';
  end if;
  return new;
end $$;

create trigger comments_text before insert on public.comments
  for each row execute function public.guard_text('body');
create trigger posts_text before insert on public.posts
  for each row execute function public.guard_text('caption');
create trigger reports_text before insert on public.reports
  for each row execute function public.guard_text('reason');
create trigger private_messages_text before insert on public.private_messages
  for each row execute function public.guard_text('body');

create trigger comments_rate_a before insert on public.comments
  for each row execute function public.guard_rate('user_id', '10 minutes', '6');
create trigger comments_rate_b before insert on public.comments
  for each row execute function public.guard_rate('user_id', '1 day', '60');
create trigger posts_rate before insert on public.posts
  for each row execute function public.guard_rate('user_id', '1 day', '5');
create trigger reports_rate_a before insert on public.reports
  for each row execute function public.guard_rate('reporter_id', '1 hour', '3');
create trigger reports_rate_b before insert on public.reports
  for each row execute function public.guard_rate('reporter_id', '1 day', '8');
create trigger likes_rate before insert on public.post_likes
  for each row execute function public.guard_rate('user_id', '1 hour', '120');
create trigger proofs_rate before insert on public.proof_submissions
  for each row execute function public.guard_rate('user_id', '1 day', '3');
create trigger private_messages_rate before insert on public.private_messages
  for each row execute function public.guard_rate('sender_id', '1 day', '200');

-- 注册开关与人数上限（只限制注册总数；本方案不能限制“同时在线人数”）
create table public.app_settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);
alter table public.app_settings enable row level security;   -- 不建策略：仅后台可改
insert into public.app_settings (key, value) values ('signup_open', 'true'), ('max_users', '300');

create function public.setting(p_key text) returns text
language sql stable security definer set search_path = '' as $$
  select value from public.app_settings where key = p_key
$$;

create function public.signup_status() returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object('open',
    coalesce(public.setting('signup_open'), 'true') = 'true'
    and (select count(*) from public.profiles) < coalesce(nullif(public.setting('max_users'), '')::int, 300))
$$;

-- v4.42: 列出没有任何帖子引用、且创建超过 30 分钟的返图对象，供版主在前端统一清理。
create function public.admin_list_orphan_images() returns setof text
language plpgsql security definer set search_path = '' as $$
begin
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if not public.has_admin_scope('content_moderation') then raise exception 'not allowed'; end if;
  return query
    select o.name
    from storage.objects o
    where o.bucket_id = 'gallery'
      and o.created_at < now() - interval '30 minutes'
      and not exists (select 1 from public.posts p where p.image_path = o.name)
    order by o.created_at
    limit 200;
end $$;

-- v4.43: 当前管理员被授予的权限范围。只用于前端决定显示哪些页面/按钮；真正的权限仍由 RLS 和各 RPC 判断。
create function public.my_scopes() returns text[]
language sql stable security definer set search_path = '' as $$
  select coalesce(array_agg(s.scope order by s.scope), '{}'::text[])
  from public.admin_scopes s
  join public.profiles p on p.id = s.user_id
  where s.user_id = (select auth.uid())
    and p.role = 'admin'
    and p.account_status = 'active';
$$;

-- v4.44: 站主（aal2）分页读取成员列表（不含站主自己、不含邮箱），每页最多 100 人。
create function public.owner_list_members(p_limit integer default 100, p_offset integer default 0) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then raise exception 'MFA aal2 required'; end if;
  if p_limit is null or p_limit < 1 or p_limit > 100 then raise exception 'page size must be 1..100'; end if;
  if p_offset is null or p_offset < 0 then raise exception 'invalid offset'; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
             'id', p.id,
             'display_name', p.display_name,
             'role', p.role,
             'account_status', p.account_status,
             'created_at', p.created_at,
             'scopes', coalesce((select jsonb_agg(sc.scope order by sc.scope)
                                 from public.admin_scopes sc where sc.user_id = p.id), '[]'::jsonb)
           ) order by p.created_at desc, p.id desc)
    from (select * from public.profiles
          where id <> (select auth.uid())
          order by created_at desc, id desc limit p_limit offset p_offset) p
  ), '[]'::jsonb);
end $$;

-- 用户可清理自己已完成（非 pending）的旧审核记录，避免 5 个对象上限永久阻断后续申请。
-- RPC 先删除数据库引用并返回路径；前端随后通过 Storage API 删除对象。若对象删除失败，孤儿清理工具可补救。
create function public.delete_own_completed_proof(p_id uuid) returns text
language plpgsql security definer set search_path = '' as $$
declare v_path text;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  delete from public.proof_submissions
   where id = p_id and user_id = auth.uid() and status <> 'pending'
   returning image_path into v_path;
  if v_path is null then raise exception 'proof not found or still pending'; end if;
  return v_path;
end $$;

-- ---------- 7. 表权限收口 ----------
-- RLS 和 SQL GRANT 是两层不同的限制，必须同时配置。
revoke all on all tables in schema public from anon, authenticated;
-- Table grants/revokes do not cover sequences. Close direct client access to public-schema sequences too.
revoke all on all sequences in schema public from anon, authenticated;

-- 匿名访客：仅能请求公开档案/模板/版本，具体行由 RLS 决定。
-- No anon grants for internal templates, characters, or character versions.
revoke all on public.templates, public.characters, public.character_versions from anon;

-- 用户资料：只读公开资料字段，只能更新自己的昵称（由 RLS 限制行）。
grant select (id, display_name, created_at) on public.profiles to authenticated;
grant update (display_name) on public.profiles to authenticated;

grant select, insert, update, delete on public.templates to authenticated;
grant select, insert, update, delete on public.characters to authenticated;
grant select, insert, update, delete on public.character_versions to authenticated;
grant select, insert on public.proof_submissions to authenticated;
grant select, insert, delete on public.posts to authenticated;
grant select, insert, delete on public.post_likes to authenticated;
grant select, insert, delete on public.comments to authenticated;
grant select, insert on public.reports to authenticated;
grant select on public.posts_with_counts to authenticated;

-- RLS 仍限制只有站主可读取站主表、审计日志与管理员权限范围。
grant select on public.site_owner, public.security_audit_log, public.admin_scopes to authenticated;

-- 私信：仅参与者可读取；客户端不能直接增删改，发送与拉黑均走受控 RPC。
grant select on public.private_messages to authenticated;
grant select on public.private_message_blocks to authenticated;

-- ---------- 8. 文件存储（全部私有桶） ----------
-- 安全预检：Storage 对象通过 bucket_id 引用桶。若同名桶使用不同 ID，或预期 ID 已被其他名称占用，
-- 不自动改 ID/名称，避免破坏 storage.objects.bucket_id 引用；先明确失败，由站主人工核对旧桶及对象。
do $$
begin
  if exists (
    select 1 from storage.buckets b
    where (b.id = 'proofs' and b.name <> 'proofs')
       or (b.id = 'gallery' and b.name <> 'gallery')
       or (b.id = 'sources' and b.name <> 'sources')
  ) then
    raise exception 'Storage bucket identity conflict: expected bucket ID is already assigned to a different name; inspect storage.buckets and storage.objects before migration.';
  end if;

  if exists (
    select 1 from storage.buckets b
    where (b.name = 'proofs' and b.id <> 'proofs')
       or (b.name = 'gallery' and b.id <> 'gallery')
       or (b.name = 'sources' and b.id <> 'sources')
  ) then
    raise exception 'Storage bucket name conflict: expected bucket name exists under a different ID; inspect storage.buckets and storage.objects before migration.';
  end if;
end $$;
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('proofs',  'proofs',  false, 3145728,  array['image/png','image/jpeg','image/webp']),   -- 审核截图 3MB
  ('gallery', 'gallery', false, 5242880,  array['image/png','image/jpeg','image/webp']),   -- 返图 5MB
  ('sources', 'sources', false, 10485760, null)                                            -- 原始资料 10MB，仅站主
on conflict (id) do update
set public = excluded.public,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

-- 文件路径约定：<用户id>/<文件名>。注意：file_size_limit 只限制上传文件大小，不会自动压缩图片；前端需先压缩并上传 Storage 路径。
create policy "proofs_insert_own" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'proofs'
    and (storage.foldername(name))[1] = (select auth.uid())::text
    -- v4.41: 每人最多 5 个审核截图对象，防止刷满免费存储
    and (select count(*) from storage.objects o
         where o.bucket_id = 'proofs'
           and (storage.foldername(o.name))[1] = (select auth.uid())::text) < 5
    and exists (
      select 1 from public.profiles p
      where p.id = (select auth.uid()) and p.account_status = 'active'
    )
  );
create policy "proofs_select_own_or_admin" on storage.objects
  for select to authenticated
  using (bucket_id = 'proofs'
         and ((storage.foldername(name))[1] = (select auth.uid())::text or public.has_admin_scope('fan_review')));
-- 用户仅能删除自己目录下的审核图片；管理员不通过 Storage 表策略直接删除他人文件。
create policy "proofs_delete_own" on storage.objects
  for delete to authenticated using (
    bucket_id = 'proofs'
    and (storage.foldername(name))[1] = (select auth.uid())::text
    -- Do not let a user delete a file while a submission row still references it.
    and not exists (
      select 1 from public.proof_submissions ps
      where ps.image_path = storage.objects.name
    )
  );

create policy "gallery_insert_fan" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'gallery'
    and public.can_speak()   -- v4.41: 与发帖资格一致，不再写死 role='fan'
    and (storage.foldername(name))[1] = (select auth.uid())::text
    -- v4.41: 每人最多 40 张返图对象
    and (select count(*) from storage.objects o
         where o.bucket_id = 'gallery'
           and (storage.foldername(o.name))[1] = (select auth.uid())::text) < 40
  );
create policy "gallery_select_fan_or_scoped_admin" on storage.objects
  for select to authenticated using (
    bucket_id = 'gallery'
    and (
      -- Owner and active scoped admins retain their moderation access.
      public.is_owner_aal2()
      or public.has_admin_scope('content_management')
      or public.has_admin_scope('content_moderation')
      or (
        -- Fans must still be approved and active; this also blocks suspended/banned users
        -- from reading their old gallery objects merely because they own the path.
        public.is_fan()
        and (
          (storage.foldername(name))[1] = (select auth.uid())::text
          or (
            not public.is_admin()
            and exists (
              select 1 from public.posts p
              where p.image_path = storage.objects.name
                and p.status = 'published'
            )
          )
        )
      )
    )
  );
-- 返图仅允许上传者删除自己的文件；管理员审核应先隐藏关联内容，不直接越权删 Storage 对象。
create policy "gallery_delete_own" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'gallery'
    and (storage.foldername(name))[1] = (select auth.uid())::text
    -- Delete the post first; this prevents published/hidden posts referencing a missing file.
    and not exists (
      select 1 from public.posts p
      where p.image_path = storage.objects.name
    )
  );

-- v4.42: 版主（aal2 + content_moderation）只能删除“已无帖子引用”的返图对象；被引用的文件仍然删不掉。
create policy "gallery_delete_moderator_unreferenced" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'gallery'
    and public.has_admin_scope('content_moderation')
    and not exists (
      select 1 from public.posts p
      where p.image_path = storage.objects.name
    )
  );

create policy "sources_owner_all" on storage.objects
  for all to authenticated
  using (bucket_id = 'sources' and public.is_owner_aal2())
  with check (bucket_id = 'sources' and public.is_owner_aal2());


-- ============================================================
-- v4.23 新增：注册前 IP/CIDR 风险拦截（需在 Supabase Auth Hooks 中单独启用）
-- 重要：这段 SQL 不会自行启用 Auth Hook；必须在 Dashboard 中将 Before User Created
-- Hook 指向 public.hook_restrict_signup_by_ip，并先在测试项目验证。
-- 只记录人工确认的拒绝网段；不自动永久封禁所有出现过的 IP，避免共享网络误伤。
-- ============================================================
create table public.signup_ip_denylist (
  cidr cidr primary key,
  reason text not null check (char_length(btrim(reason)) between 1 and 300),
  created_at timestamptz not null default now()
);
alter table public.signup_ip_denylist enable row level security;
revoke all on public.signup_ip_denylist from public, anon, authenticated;
-- SECURITY INVOKER means the Auth role must pass RLS as well as SQL GRANT.
-- Give only supabase_auth_admin read access for the signup hook; clients remain excluded.
create policy "signup_ip_denylist_auth_hook_read"
  on public.signup_ip_denylist for select to supabase_auth_admin using (true);
grant select on public.signup_ip_denylist to supabase_auth_admin;

create function public.hook_restrict_signup_by_ip(event jsonb)
returns jsonb
language plpgsql
security invoker
set search_path = ''
as $$
declare
  ip_text text;
  request_ip inet;
  denied boolean;
begin
  ip_text := nullif(btrim(event->'metadata'->>'ip_address'), '');

  -- Supabase documents metadata.ip_address as a required Before User Created field.
  -- If it is absent, fail closed instead of silently bypassing the network denylist.
  -- This is a verification failure, not a claim that the user is abusive.
  if ip_text is null then
    return jsonb_build_object(
      'error', jsonb_build_object(
        'message', 'Signup request could not be verified. Please try again later.',
        'http_code', 400
      )
    );
  end if;

  -- Treat malformed metadata as a hook error rather than silently interpreting it as a match.
  begin
    request_ip := ip_text::inet;
  exception when invalid_text_representation then
    return jsonb_build_object(
      'error', jsonb_build_object(
        'message', 'Signup request could not be verified. Please try again later.',
        'http_code', 400
      )
    );
  end;

  select exists (
    select 1
    from public.signup_ip_denylist d
    where request_ip <<= d.cidr
  ) into denied;

  if denied then
    return jsonb_build_object(
      'error', jsonb_build_object(
        'message', 'Signups are temporarily unavailable from this network. If you believe this is an error, contact the site owner.',
        'http_code', 403
      )
    );
  end if;

  return '{}'::jsonb;
end;
$$;

-- Supabase Auth Hook caller needs schema USAGE to resolve this function and its qualified table reference.
-- This does not grant CREATE and does not expose the denylist to client roles.
grant usage on schema public to supabase_auth_admin;
revoke execute on function public.hook_restrict_signup_by_ip(jsonb) from public, anon, authenticated;


-- v4.35: normalize ACLs only for functions declared by this application schema.
-- Do not change unrelated public-schema functions that may belong to extensions or other app components.
revoke execute on function public.is_owner() from public, anon, authenticated, service_role;
revoke execute on function public.is_admin() from public, anon, authenticated, service_role;
revoke execute on function public.has_admin_scope(text) from public, anon, authenticated, service_role;
revoke execute on function public.owner_set_admin_scope(uuid, text, boolean) from public, anon, authenticated, service_role;
revoke execute on function public.is_fan() from public, anon, authenticated, service_role;
revoke execute on function public.my_role() from public, anon, authenticated, service_role;
revoke execute on function public.can_view(text) from public, anon, authenticated, service_role;
revoke execute on function public.handle_new_user() from public, anon, authenticated, service_role;
revoke execute on function public.my_account() from public, anon, authenticated, service_role;
revoke execute on function public.my_account_level() from public, anon, authenticated, service_role;
revoke execute on function public.can_speak() from public, anon, authenticated, service_role;
revoke execute on function public.owner_set_admin(uuid, boolean) from public, anon, authenticated, service_role;
revoke execute on function public.owner_set_account_status(uuid, text) from public, anon, authenticated, service_role;
revoke execute on function public.enforce_nickname_change_cooldown() from public, anon, authenticated, service_role;
revoke execute on function public.touch_updated_at() from public, anon, authenticated, service_role;
revoke execute on function public.validate_proof_storage_reference() from public, anon, authenticated, service_role;
revoke execute on function public.review_proof() from public, anon, authenticated, service_role;
revoke execute on function public.admin_review_proof(uuid, text, text) from public, anon, authenticated, service_role;
revoke execute on function public.validate_gallery_storage_reference() from public, anon, authenticated, service_role;
revoke execute on function public.validate_report_target() from public, anon, authenticated, service_role;
revoke execute on function public.admin_set_report_status(uuid, text) from public, anon, authenticated, service_role;
revoke execute on function public.admin_set_post_status(uuid, text) from public, anon, authenticated, service_role;
revoke execute on function public.admin_delete_post(uuid) from public, anon, authenticated, service_role;
revoke execute on function public.admin_delete_comment(uuid) from public, anon, authenticated, service_role;
revoke execute on function public.admin_set_comment_status(uuid, text) from public, anon, authenticated, service_role;
revoke execute on function public.send_private_message(uuid, text) from public, anon, authenticated, service_role;
revoke execute on function public.owner_set_private_message_block(uuid, boolean, text) from public, anon, authenticated, service_role;
revoke execute on function public.hook_restrict_signup_by_ip(jsonb) from public, anon, authenticated, service_role;

-- Explicit allowlist of functions intended to be callable through the Data API.
grant execute on function public.is_owner() to authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_fan() to authenticated;
grant execute on function public.can_view(text) to authenticated;
grant execute on function public.my_role() to authenticated;
grant execute on function public.my_account() to authenticated;
grant execute on function public.my_account_level() to authenticated;
grant execute on function public.can_speak() to authenticated;
grant execute on function public.owner_set_admin(uuid, boolean) to authenticated;
grant execute on function public.owner_set_account_status(uuid, text) to authenticated;
grant execute on function public.has_admin_scope(text) to authenticated;
grant execute on function public.owner_set_admin_scope(uuid, text, boolean) to authenticated;
grant execute on function public.admin_review_proof(uuid, text, text) to authenticated;
grant execute on function public.admin_set_report_status(uuid, text) to authenticated;
grant execute on function public.admin_set_post_status(uuid, text) to authenticated;
grant execute on function public.admin_set_comment_status(uuid, text) to authenticated;
grant execute on function public.admin_delete_post(uuid) to authenticated;
grant execute on function public.admin_delete_comment(uuid) to authenticated;

grant execute on function public.send_private_message(uuid, text) to authenticated;
grant execute on function public.owner_set_private_message_block(uuid, boolean, text) to authenticated;
grant execute on function public.hook_restrict_signup_by_ip(jsonb) to supabase_auth_admin;
-- v4.41 新增函数授权：策略/触发器以调用者身份执行，需要 EXECUTE；其余内部函数保持无授权。
grant execute on function public.is_owner_aal2() to authenticated;
grant execute on function public.normalize_text(text) to authenticated;
grant execute on function public.spam_reason(text) to authenticated;
grant execute on function public.signup_status() to anon, authenticated;
revoke execute on function public.admin_list_orphan_images() from public, anon;
grant execute on function public.admin_list_orphan_images() to authenticated;
revoke execute on function public.my_scopes() from public, anon;
revoke execute on function public.owner_list_members(integer, integer) from public, anon;
grant execute on function public.my_scopes() to authenticated;
grant execute on function public.owner_list_members(integer, integer) to authenticated;
revoke execute on function public.delete_own_completed_proof(uuid) from public, anon, service_role;
grant execute on function public.delete_own_completed_proof(uuid) to authenticated;

-- ============================================================
-- 首次部署后必须完成的初始化（不要提前运行）：
-- 1. 在网页/Auth 中注册站主账号并登录，启用 Supabase Authenticator MFA。
-- 2. 确认 JWT aal2 后，在 SQL Editor 以项目数据库管理员身份执行下方语句，
--    将邮箱替换为你自己的注册邮箱。只执行一次；执行前务必核对邮箱。
--
-- insert into public.site_owner (singleton, user_id)
-- select true, id from auth.users where lower(email) = lower('你的注册邮箱');
--
-- 3. 立刻核对：select * from public.site_owner;
-- 4. 不要把 service_role key 放进 HTML、GitHub 仓库或聊天记录。
--
-- 重要限制：本脚本是待验证草稿，不是已测试的生产级安全认证方案。
-- `aal2` 检查只验证当前会话的 MFA assurance level；你仍需在 Supabase Auth 中配置 MFA，
-- 并实测登录、恢复、角色授权、RLS 与 Storage。首个站主设置应在测试项目先验证。
-- ============================================================

-- v4.36 review note: admin mutation RPCs require aal2 in addition to scope checks; verify with real Supabase JWT/RPC tests before deployment.

-- v4.38 review note: anon has no grants/policies for internal character/template/version tables; authenticated reads require active approved membership (fan/admin) or owner. Speaking remains separately gated by can_speak() and the 7-day account age. Validate with real Supabase JWTs before deployment.

-- v4.41 review note: 站主初始化(site_owner)后，站主昵称需用 SQL Editor 设为 64426：
--   update public.profiles set display_name = '64426' where id = (select user_id from public.site_owner);
-- 站主必须先完成 MFA 绑定，否则 aal1 会话下读不到任何受保护数据（这是有意的）；万一丢失验证器，用 SQL Editor 恢复。
-- 调整注册上限：update public.app_settings set value = '100' where key = 'max_users';
-- 处理违规账号：update public.profiles set account_status = 'banned' where id = '<用户UUID>';（SQL Editor 内执行）
-- v4.39 review note: active admin status now requires at least one current scope for membership/admin helper checks and speaking eligibility. PostgreSQL/Supabase execution remains unverified.
